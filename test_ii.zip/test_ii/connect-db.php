<?php
	class Connectinfo {
		public static $host = 'localhost';
		public static $username = 'root';
		public static $password = '';
		public static $dbname = 'dbusers';
		
	}
