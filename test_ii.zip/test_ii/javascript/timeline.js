

	$( document ).ready(function() {
		render();
	
	
		// hise current post
		 $('body').on('click', '.posthider', function() {
			$(this).parentsUntil(".timeline-block").hide();
		});
		
		
		$('body').on('click', '#addon #openpanel', function() {
			$(this).hide();
			$("#addonpanel").show();
		});
		
		$('body').on('click', '#addon #cancel', function() {
			$("#addonpanel").hide();
			$("#addon #openpanel").show();
		});
		
	
		$('body').on('click', '#addon #add', function() {
			insertrecord();
		});
	
	
		
	});


	function render(){
	
		  $.ajax({ 

            url: "getrecords_ajax.php",

          }).done(function( data ) { 

            var result= $.parseJSON(data); 
            var string="";
 
			var counter = 1;
			var loc = "";
 
            $.each( result, function( key, value ) { 
              
				if (counter % 2 == 0){
					loc = "right";
				} else {
					loc = "left";
				}
			  
				
				string += '<div class="timeline-block timeline-block-' + loc + '">';
				string += '<div class="marker"></div>';
				string += '<div class="timeline-content">';
			    string += '<p>' + value['post_content']  + '</p>';
				string += '<input type="button" value ="hide this post" class="posthider" />';
				string += '</div>';
			    string += '</div>';
			  
			  
				counter++;
						
            }); 

       

              $("#records").html(string); 
           });
	
	}
	
	function insertrecord(){
		
			$.ajax({
				
				url: "addrecord_ajax.php",
				type : "POST",
				
				data: {
					post_content: $("#post_content").val()	
					
				},
				success: function(resault){
					
					if (resault == 1){
						render();
						$("#addonpanel").hide();
						$("#post_content").val("");
						$("#addon #openpanel").show();
					}
				}
				
				
				
			});
		
		
	}
	

	
	
	
	
	
	