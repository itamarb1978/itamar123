<?php 
    
	function addrecord(){
		
		require_once("connect-db.php");
		
		$result_array = array();
		/* Create connection */
		$conn = new mysqli(Connectinfo::$host, Connectinfo::$username, Connectinfo::$password, Connectinfo::$dbname);

		$conn->set_charset("utf8");
		
		/* Check connection  */
		if ($conn->connect_error) {
			 die("Connection to database failed: " . $conn->connect_error);
		}
		
		$post_content = mysqli_real_escape_string($conn, $_POST["post_content"]);
		$sql = "INSERT INTO users (post_content) VALUES ('{$post_content}')";
		
		if ($conn->query($sql) === TRUE){
			echo 1;
		} else {
			echo 0;
		}
		
		$conn->close();
	
	}

	addrecord();